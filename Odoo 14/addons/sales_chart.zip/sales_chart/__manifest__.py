{
    "name": "Sales Chart",
    "depends": ["base", "sale", "sale_management"],
    "data": [
        "assets.xml",
        "views.xml"
    ],
    "qweb": [
        "static/src/xml/sales.xml"
    ]
}